Changelog for java-adt
======================

0.2018.11.4
-----------

- fixed compilation with ghc-8.4.4 and ghc-8.6.1
