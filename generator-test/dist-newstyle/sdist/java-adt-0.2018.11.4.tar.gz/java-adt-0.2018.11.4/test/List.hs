data List A = Nil | Cons { head :: A, tail :: List A }
