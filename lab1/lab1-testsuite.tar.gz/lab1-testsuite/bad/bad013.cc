return foo(double x) {
	return x + 9;
}
