int foo() return 1;
