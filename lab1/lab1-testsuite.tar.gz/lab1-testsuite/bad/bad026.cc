int main () {
	45
	return 0;
}
