int foo() {
	while (return 5) 45;
	return x;
}
