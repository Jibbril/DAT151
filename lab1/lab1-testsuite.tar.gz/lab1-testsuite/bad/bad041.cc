int foo() {
	x = x[++];
}
