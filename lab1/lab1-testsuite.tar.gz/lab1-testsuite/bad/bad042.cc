int foo() {
	throw (if 2 then 3 else 4);
}
