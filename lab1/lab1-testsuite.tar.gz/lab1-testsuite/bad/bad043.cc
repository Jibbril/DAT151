int foo() {
	int int;	
}
