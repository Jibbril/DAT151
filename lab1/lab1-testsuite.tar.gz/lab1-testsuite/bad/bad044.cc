int foo() {
	printf("foo" "bar" 42);
}
