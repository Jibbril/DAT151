void foo(int& = 4) {

}
