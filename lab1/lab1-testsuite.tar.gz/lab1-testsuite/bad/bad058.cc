int &foo&;
