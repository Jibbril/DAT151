using ::foo;
