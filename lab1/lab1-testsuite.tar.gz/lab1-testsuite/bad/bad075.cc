using (3*x);
