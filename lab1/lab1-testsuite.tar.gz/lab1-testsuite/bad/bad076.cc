(cout << 5) bar () {}
