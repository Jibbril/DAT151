int foo(const (4));
