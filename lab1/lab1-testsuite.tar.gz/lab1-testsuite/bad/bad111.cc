int main () {
	(2+3) "foo";
}
