int main() { int i,; }
