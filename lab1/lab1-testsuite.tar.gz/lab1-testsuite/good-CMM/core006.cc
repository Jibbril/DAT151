// Declaration of multiple variables of the same type in one statement:

int main () {
  int x, y;
  x = 45;
  y = 36 + 67;
  printInt(x);
  printInt(y);
  return 0 ;
}
