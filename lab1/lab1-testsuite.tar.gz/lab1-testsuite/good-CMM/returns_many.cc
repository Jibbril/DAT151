int r() {
  return 12;
  return 2;
  return 3;
}

int main() {
  printInt(r());
  return 0;
  return 2;
}
