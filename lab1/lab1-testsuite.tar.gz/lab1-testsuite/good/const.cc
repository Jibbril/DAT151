int main(const int y) { const int x; }
