a::b::c banana() {}
a::b::c::q banana2() {}
d banana_3(int x, a::b::c::q);
