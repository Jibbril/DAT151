int main() {
	sigaction_t s;
	s.sa_handler;
	sigaction_p sp;
	sp->sa_handler(5);
	sp->sa_flags = 34;
}
