// map is not a built-in name, it's an identifier
typedef int map;
map x = 2;
