int main () {
	int foo = x::i;
}
