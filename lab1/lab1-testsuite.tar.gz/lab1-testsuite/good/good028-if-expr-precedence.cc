int main() {
	int y;
	int x = y = 1;
	int z = x == 1 ? 2 : 3;
}
