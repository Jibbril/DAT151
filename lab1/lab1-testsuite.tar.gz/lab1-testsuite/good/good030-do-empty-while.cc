int main() {
	int x = 1;
	do { } while (x == 4);
}
