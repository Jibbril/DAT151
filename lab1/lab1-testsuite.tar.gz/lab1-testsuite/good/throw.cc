int main() {
  throw x;
  throw throw x;
  throw throw throw x;
}
