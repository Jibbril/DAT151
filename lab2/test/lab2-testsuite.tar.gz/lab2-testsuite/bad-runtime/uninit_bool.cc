int main() {
  bool a;
  bool b = a && true;

  return 0;
}
