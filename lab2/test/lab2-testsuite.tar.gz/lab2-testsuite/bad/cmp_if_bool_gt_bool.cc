int main () {
	if (true > false) { } else { }
	return 0;
}
