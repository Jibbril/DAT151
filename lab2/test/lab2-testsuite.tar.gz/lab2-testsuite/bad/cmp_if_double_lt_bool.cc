int main () {
	if (5.324 < true) { } else { }
  return 0;
}
