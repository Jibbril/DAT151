// 1 instead of 2 arguments

int main() {
	int x = foo(1);
	return 0 ;
}

int foo(int y,int z) {
 return y;
}

