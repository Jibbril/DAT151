int main() {
  int x = foo(11, true);
  return 22;
}

int foo(int x, int y) {
  return y;
}
