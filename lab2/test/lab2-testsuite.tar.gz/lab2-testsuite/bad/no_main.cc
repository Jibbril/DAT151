int not_main() {
  return 0;
}
