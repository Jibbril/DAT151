int bar(int x) {
	int x;
        return x;
}

int main() { return 0; }
