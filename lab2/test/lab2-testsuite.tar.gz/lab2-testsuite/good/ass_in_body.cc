int f(int x) {
        x = 7;
        return x;
}

int main() {
        printInt(f(5));
        return 0;
}
