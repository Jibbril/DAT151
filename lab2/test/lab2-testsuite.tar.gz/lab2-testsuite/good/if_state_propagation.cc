int main() {
  int x;

  if ((x = 1) == 1) {} else {}

  printInt(x);

  return 0;
}
