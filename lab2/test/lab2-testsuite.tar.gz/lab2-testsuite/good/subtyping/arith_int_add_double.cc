int main() {
  double x;
  x = 1 + 1.1;
  return 0;
}
