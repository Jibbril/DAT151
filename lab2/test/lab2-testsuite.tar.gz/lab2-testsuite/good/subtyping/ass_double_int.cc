int main() {
  double d = 1;
  d = d / 2;
  printDouble(d);
  return 0;
}
