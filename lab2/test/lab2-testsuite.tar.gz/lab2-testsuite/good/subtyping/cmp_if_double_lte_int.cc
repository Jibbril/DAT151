int main () {
	if (3.0 <= 5)
		int y;
	else {}
	return 0;
}
