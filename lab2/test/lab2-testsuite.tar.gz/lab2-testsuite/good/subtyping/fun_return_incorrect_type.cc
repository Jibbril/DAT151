int main() {
  if (c(99) == 99.0) printInt(1); else printInt(0);
  return 0;
}

double c(int x) {
  return x;
}
