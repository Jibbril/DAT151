double have_an_int() {
  return 1;
}

int main() {
  printDouble(have_an_int() / 2);
  return 0;
}
