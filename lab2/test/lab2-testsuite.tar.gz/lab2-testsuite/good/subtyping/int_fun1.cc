double have_an_int(double arg) {
  return arg / 2;
}

int main() {
  printDouble(have_an_int(1));
  return 0;
}
