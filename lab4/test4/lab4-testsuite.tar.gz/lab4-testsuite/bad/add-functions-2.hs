K1 ignore = 1;

main = print (K1 + 1);
