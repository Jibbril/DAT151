a b = c;

d c = a c;

main = print (d 111);
