Y f y = f y;

main = print (Y (\x -> y) 888);
