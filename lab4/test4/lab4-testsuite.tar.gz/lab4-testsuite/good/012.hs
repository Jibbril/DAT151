main = print (if 0 < 0 then 1 else 0) ;  -- result 0
