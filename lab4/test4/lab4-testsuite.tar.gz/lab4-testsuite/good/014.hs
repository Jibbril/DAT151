main = print (if 1 < 2 then 33 else 44) ;  -- result 33
