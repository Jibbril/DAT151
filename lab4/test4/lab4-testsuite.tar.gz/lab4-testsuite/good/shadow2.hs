one = 2 ;
two one = one ;

main = print (two 1) ;
